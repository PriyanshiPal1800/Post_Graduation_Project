﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace Project_demo
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename='E:\\Khushi\\DB.mdf';Integrated Security=True;Connect Timeout=30");
       
        protected void Page_Load(object sender, EventArgs e)
        {
          if(Panel1.CssClass=="P2")
            {
                Panel1.CssClass = "P1";
                TextBox1.Visible = false;
                Label1.Visible = false;
            }
          else
            {
                Panel1.CssClass = "P2";
                TextBox1.Visible = true;
                Label1.Visible = true;
            }


            if (Panel1.CssClass == "sidebar1")
            {
                Panel1.CssClass = "sidebar2";
                
            }
            else
            {
                Panel1.CssClass = "sidebar1";
                
            }







        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           
        }
    }
}