﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace Project_demo
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename='E:\\Khushi\\DB.mdf';Integrated Security=True;Connect Timeout=30");
        string selectCommand2;
        protected void Page_Load(object sender, EventArgs e)
        {
            con.Open();
            selectCommand2 = "SELECT * FROM Donation Inner Join users on Donation.user_id=users.user_id ";
            SqlCommand da = new SqlCommand(selectCommand2, con);
            SqlDataReader dr1;
            dr1 = da.ExecuteReader();
            DataTable tbl = new DataTable("DN");
            DataColumn col;
            DataRow row;
            col = new DataColumn();
            col.DataType = typeof(String);
            col.ColumnName = "user_name";
            tbl.Columns.Add(col);

            col = new DataColumn();
            col.DataType = typeof(String);
            col.ColumnName = "Amount";
            tbl.Columns.Add(col);

            while (dr1.Read())
            {
                row = tbl.NewRow();
                row["user_name"] = dr1["firstname"].ToString();
                row["Amount"] = dr1["amount"];


                tbl.Rows.Add(row);
            }

            ListView1.DataSource = tbl;
            ListView1.DataBind();
            con.Close();



        }
    }
}