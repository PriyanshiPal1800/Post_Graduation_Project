﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace temple_page_1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename='E:\\Khushi\\DB.mdf';Integrated Security=True;Connect Timeout=30");
       
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Button Button1 = (sender as Button);
            Session["temple"] = Button1.CommandArgument;
            Response.Redirect("Temple1.aspx");
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Button Button2 = (sender as Button);
            Session["ngo"] = Button2.CommandArgument;
            Response.Redirect("NgoPage.aspx");
        }
    }
}