﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Project_demo
{
    public partial class Login11 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename='E:\\Khushi\\DB.mdf';Integrated Security=True;Connect Timeout=30");

        protected void btnLogin_Click(object sender, EventArgs e)
        {

            


            int s1 = 0;          //if user is invalid s1=0 
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM users", con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
               if (Convert.ToString(dr["email_id"]) == txtEmail.Text) 
                {
                    if (Convert.ToString(dr["password"]) == txtPwd.Text)
                    {
                        s1 = 1;
                        Session["user"] = dr["user_id"];
                    }
                    else
                    {
                        s1 = 2;
                        break;
                    }
                }
            }
            if (s1 == 0)                 // user is not registered
            {
                txtEmail.Text = "";
                txtPwd.Text = "";
                lblError.Text = "Not Registered User!!";
            }
            else if (s1 == 1)              //Login Successful
            {
                if (Convert.ToString(Session["user"]) == "U0")
                {
                    Session["admin"] = "true";
                    Response.Redirect("admin/AdminDashboard.aspx");
                }
                else
                {
                    Response.Redirect(Session["page"].ToString());
                }
            }
            else if (s1 == 2)              //correct email & incorrect password
            {
                txtPwd.Text = "";
                lblError.Text = "Wrong Password";
            }
            con.Close();
        }
    }
}